from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import sqlite3
from functools import wraps
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

def get_db_connection():
    conn = sqlite3.connect('docure.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute('''CREATE TABLE IF NOT EXISTS users
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     email TEXT UNIQUE NOT NULL,
                     password TEXT NOT NULL,
                     name TEXT NOT NULL)''')
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        conn.close()
        if user and user['password'] == password:
            session['user_id'] = user['id']
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password', 'error')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        name = request.form['name']
        conn = get_db_connection()
        existing_user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        if existing_user:
            flash('Email already exists', 'error')
        else:
            conn.execute('INSERT INTO users (email, password, name) VALUES (?, ?, ?)',
                         (email, password, name))
            conn.commit()
            flash('Account created successfully!', 'success')
            return redirect(url_for('login'))
        conn.close()
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logged out successfully', 'success')
    return redirect(url_for('index'))

with open('medical_qa.json', 'r') as f:
    medical_qa = json.load(f)

@app.route('/chatbot', methods=['GET', 'POST'])
@login_required
def chatbot():
    if request.method == 'POST':
        user_message = request.form['message'].lower()
        response = "I'm sorry, I don't have information about that. Please consult a healthcare professional for medical advice."
        
        for qa in medical_qa:
            if any(keyword in user_message for keyword in qa['keywords']):
                response = qa['answer']
                break
        
        return jsonify({'response': response})
    return render_template('chatbot.html')

@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    # Mock data for dashboard
    appointments = [
        {'doctor': 'Dr. Smith', 'date': '2024-10-15', 'time': '14:00'},
        {'doctor': 'Dr. Johnson', 'date': '2024-10-20', 'time': '10:30'}
    ]
    nearby_doctors = [
        {'name': 'Dr. Brown', 'specialty': 'Cardiology', 'distance': '2.5 km'},
        {'name': 'Dr. Davis', 'specialty': 'Pediatrics', 'distance': '3.1 km'}
    ]
    return render_template('dashboard.html', user=user, appointments=appointments, nearby_doctors=nearby_doctors)

@app.route('/location-permission')
@login_required
def location_permission():
    return render_template('location_permission.html')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)